//(function-1) which is responsible for making qty field enable and disable based on checkbox check or unchecked and also removes row onclick of remove icon
const rows = document.querySelectorAll("#cart tr");
const checkoutBtn = document.getElementById("checkoutBtn");

rows.forEach(row => {
    const checkbox = row.querySelector(".check");
    const qty = row.querySelector(".qty");
    const remove = row.querySelector(".remove");

    checkbox.addEventListener("change", () => {
        if (checkbox.checked) {
            qty.disabled = false;
            qty.value = 1;
        } else {
            qty.disabled = true;
            qty.value = "";
            row.querySelector(".itemTotal").innerText = 0;
        }
        calculate();
    });

    qty.addEventListener("input", calculate);

    remove.addEventListener("click", () => {
        row.style.display = "none";
        checkbox.checked = false;
        calculate();
    });
});
//(function-1) completed



//(function-2) it is used to count total items,subtotal and final total value and display it in totalAmt in its co-responding fields
function calculate() {
    let subtotal = 0;
    let totalItems = 0;
    let anyChecked = false;

    rows.forEach(row => {
        if (row.style.display !== "none") {
            const checkbox = row.querySelector(".check");
            const qty = row.querySelector(".qty");
            const price = parseFloat(row.dataset.price);

            if (checkbox.checked && qty.value > 0) {
                const itemTotal = price * qty.value;
                row.querySelector(".itemTotal").innerText = itemTotal.toFixed(2);
                subtotal += itemTotal;
                totalItems += parseInt(qty.value);
                anyChecked = true;
            }
        }
    });

    const gst = subtotal * 0.18;

    document.getElementById("totalItems").innerText = totalItems;
    document.getElementById("subTotal").innerText = subtotal.toFixed(2);
    document.getElementById("gst").innerText = gst.toFixed(2);
    document.getElementById("grandTotal").innerText = (subtotal + gst).toFixed(2);

    checkoutBtn.disabled = !anyChecked;
}
//(function-2) completed



//(function-3) used to set the formate of billing date and delivery date and adding the content in alert box
function checkout() {

    let billDate = new Date();
    let billDateFormatted = billDate.toLocaleDateString("en-GB");

    let deliveryDate = new Date();
    deliveryDate.setMonth(deliveryDate.getMonth() + 1);
    let deliveryDateFormatted = deliveryDate.toLocaleDateString("en-GB", {
        day: "2-digit",
        month: "short",
        year: "numeric"
    });

    alert(
        "Total Item: " + document.getElementById("totalItems").innerText + "\n" +
        "Total Amount: $" + document.getElementById("grandTotal").innerText + "\n" +
        "Bill Date: " + billDateFormatted + "\n" +
        "Delivery Date: " + deliveryDateFormatted + "\n\n" +
        "Confirm Order?"
    );

    showToast();
    resetAll();
}
//(function-3) completed



//(function-4) used for showing toast and manage its duration
function showToast() {
    const toast = document.getElementById("toast");
    toast.classList.add("show");
    setTimeout(() => toast.classList.remove("show"), 3000);
}



//(function-5) after successful order reseting the fields
function resetAll() {
    rows.forEach(row => {
        row.style.display = "";
        row.querySelector(".check").checked = false;
        row.querySelector(".qty").value = "";
        row.querySelector(".qty").disabled = true;
        row.querySelector(".itemTotal").innerText = 0;
    });

    document.getElementById("totalItems").innerText = 0;
    document.getElementById("subTotal").innerText = 0;
    document.getElementById("gst").innerText = 0;
    document.getElementById("grandTotal").innerText = 0;

    checkoutBtn.disabled = true;
}



