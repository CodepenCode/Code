// Getting all the input fields using its ID
const otherChk = document.getElementById("otherChk");
const otherBox = document.getElementById("otherBox");
const state2 = document.getElementById("state2");
const city2 = document.getElementById("city2");
const terms = document.getElementById("terms");
const submitBtn = document.getElementById("submitBtn");
const state1 = document.getElementById("state1");
const city1 = document.getElementById("city1");

//Function used to Prevent other character except alphabet in input field First name , middle name & last name
function onlyAlpha(el) {
    el.value = el.value.replace(/[^A-Za-z]/g, "");
}

//event which is responsible for displaying textbox when user checked on other interest checkbox
otherChk.onclick = () => {
    otherBox.style.display = otherChk.checked ? "block" : "none";
    if (!otherChk.checked) otherBox.value = "";
};

//event which is responsible for making city1 dropdown enable and disable based on its state1's value
state1.onchange = () => {
    if (state1.value === "") {
        city1.disabled = true;
        city1.value = "";
    } else {
        city1.disabled = false;
        city1.value = "";
    }
};

//event which is responsible for making city2 dropdown enable and disable based on its state2's value
state2.onchange = () => {
    if (state2.value === "") {
        city2.disabled = true;
        city2.value = "";
    } else {
        city2.disabled = false;
        city2.value = "";
    }
};


//event which is responsible for making submit button enable and disable on change of terms checkbox
terms.onchange = () => {
    submitBtn.disabled = !terms.checked;
};

//function which is responsible for highlighiting the empty or errorneous input field
function error(el, msg) {
    el.classList.add("error");
    el.focus();
    alert(msg);

    const removeError = () => {
        if ((el.tagName === "INPUT" && el.value.trim() !== "") ||
            (el.tagName === "TEXTAREA" && el.value.trim() !== "") ||
            (el.tagName === "SELECT" && el.value !== "") ||
            ((el.type === "checkbox" || el.type === "radio") && el.checked)) {
            el.classList.remove("error");
            el.removeEventListener("input", removeError);
            el.removeEventListener("change", removeError);
        }
    };
    el.addEventListener("input", removeError);
    el.addEventListener("change", removeError);

    return false;
}

//function which is used to validate the input field's data
function validate() {
    document.querySelectorAll("input,select").forEach(e => e.classList.remove("error"));

    //first name empty field and character only validation
    if (fname.value === "")
        return error(fname, "📛 Please enter First Name");
    if (!/^[A-Za-z]+$/.test(fname.value))
        return error(fname, "📛 First Name must contain only alphabets");

    //Middle name empty field validation
    if (mname.value !== "" && !/^[A-Za-z]+$/.test(mname.value))
        return error(mname, "📛 Middle Name must contain only alphabets");

    //Last name empty field and character only validation
    if (lname.value === "")
        return error(lname, "📛 Please enter Last Name");
    if (!/^[A-Za-z]+$/.test(lname.value))
        return error(lname, "📛 Last Name must contain only alphabets");

    //Email empty field and its validation
    if (email.value === "")
        return error(email, "📧 Please enter Email");
    if (!/^[\w.%+-]+@[\w.-]+\.[A-Za-z]{2,}$/.test(email.value))
        return error(email, "📧 Please enter valid Email");

    //Password field validation
    if (password.value === "")
        return error(password, "🔑 Please enter Password");
    if (!/^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[@$!%*?&]).{8,}$/.test(password.value))
        return error(password, "🔐 Password must be strong (1 cap, 1 small, 1 Special char, 1 Numeric, minimum 8 char)");

    //Bday and age empty field validation
    if (bdate.value === "")
        return error(bdate, "📆 Please select Birth Date");
    if (age.value === "")
        return error(age, "📆 Please enter Age");

    //Gender radio button not any selected validation
    if (!document.querySelector('input[name="gender"]:checked')) {
        return error(document.querySelector('input[name="gender"]'), "👥 Please select Gender");
    }

    //interest checkbox atlist one is checked validation
    const interestCount = document.querySelectorAll(".interest:checked").length;
    if (interestCount === 0 && !otherChk.checked) {
        return error(otherChk, "✨ Please select at least one Interest");
    }

    //if other checkbox is checked its input textbox empty field validation
    if (otherChk.checked && otherBox.value === "")
        return error(otherBox, "✨ Please enter Other Interest");

    //state1 and city1 validation
    if (state1.value === "")
        return error(state1, "🏛️ Please select State 1");
    if (city1.value === "")
        return error(city1, "📍 Please select City 1");

    //if state2 is not empty then city2 must be selected validation
    if (state2.value !== "" && city2.value === "")
        return error(city2, "📍 Please select City 2");

    //terms checkbox validation but not needed because submit button is disabled
    // if (!terms.checked) {
    //     return error(terms, "⚠️ Please accept Terms & Conditions");
    // }

    //alert tells form is successfully submited and make submit button city1 and city2 disable again
    alert(" ✅ Form Submitted Successfully");
    document.myForm.reset();
    submitBtn.disabled = true;
    city1.disabled = true;
    city2.disabled = true;
    otherBox.style.display="none";
}
